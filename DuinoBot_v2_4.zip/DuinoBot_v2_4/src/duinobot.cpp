#include "duinobot.h"
DuinoBotClass::DuinoBotClass(){

}

int DuinoBotClass::convertDigitalSpeed(int speed) {
	float dspeed;
	dspeed = (speed*255)/100;
	return (int)dspeed;
}
	
void DuinoBotClass::ctrlMotor(int motor, int speed) {
	if (motor==1) {
		if (speed > 0) {
			analogWrite(MOTOR1_ENA, convertDigitalSpeed(speed));
			digitalWrite(MOTOR1_D0,1);
			digitalWrite(MOTOR1_D1,0);
		} else {
			analogWrite(MOTOR1_ENA, convertDigitalSpeed(speed*(-1)));
			digitalWrite(MOTOR1_D0,0);
			digitalWrite(MOTOR1_D1,1);
		}
	} else {
		if (speed > 0) {
			analogWrite(MOTOR0_ENA, convertDigitalSpeed(speed));
			digitalWrite(MOTOR0_D0,1);
			digitalWrite(MOTOR0_D1,0);
		} else {
			analogWrite(MOTOR0_ENA, convertDigitalSpeed(speed*(-1)));
			digitalWrite(MOTOR0_D0,0);
			digitalWrite(MOTOR0_D1,1);
		}
	}
}


