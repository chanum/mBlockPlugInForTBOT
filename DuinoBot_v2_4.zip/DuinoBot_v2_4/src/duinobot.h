#ifndef duinobot_h
#define duinobot_h

#include <Arduino.h>

#define MOTOR0_ENA	6
#define MOTOR0_D0 	5
#define MOTOR0_D1	7

#define MOTOR1_ENA	3
#define MOTOR1_D0 	4
#define MOTOR1_D1 	2


///@brief Class for DuinoBotClass
class DuinoBotClass
{
	public:
		DuinoBotClass();
		int convertDigitalSpeed(int speed);
		void ctrlMotor(int motor, int speed);
	private:

};

#endif